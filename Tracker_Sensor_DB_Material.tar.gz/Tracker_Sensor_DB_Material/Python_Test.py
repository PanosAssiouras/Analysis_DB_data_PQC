import os
import pathlib
import numpy as np
import pandas as pd
from scipy import stats

path = pathlib.Path().absolute()
print(path)
